<?php
	header( 'Location: index.php?rt=predmeti' );
?>