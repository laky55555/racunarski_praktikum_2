/**
 * Objekt koji sadrzi sve potrebno za crtanje grafa.
 */
function Graf() {
	/**
	 * Niz imena elemenata kojih prikazujemo u grafu.
	 */
	this.nazivi = [];
	/**
	 * Niz koji sadrzi nizove vrijednosti za svaki element.
	 */
	this.vrijednosti = [];
	/**
	 * Niz koji sadrzi imena razlicitih grupa za iste predmete.
	 */
	this.dataset = [];
	/**
	 * Naziv na x osi, prazan string ako ga nema.
	 */
	this.xlabel = "";
	/**
	 * Naziv na y osi, prazan string ako ga nema.
	 */
	this.ylabel = "";
	/**
	 * Naslov grafa, prazan stirng ako ga nema.
	 */
	this.title = "";
}

/**
 * Niz boja potrebnih za crtanje razlicitih grupa istog elementa.
 * @type {Array}
 */
var boje = ["blue", "red", "green", "yellow", "gray"];

/**
 * Metoda objekta Graf zaduzena za ispis svih podataka o grafu.
 */
Graf.prototype.ispis = function() {
	console.log("Naslov = " + this.title);
	console.log("Xlabel = " + this.xlabel);
	console.log("Ylabel = " + this.ylabel);
	for (var i = 0; i < this.nazivi.length; i++) {
		var vrijednosti = [];
		for (var j = 0; j < this.vrijednosti.length; j++)
			vrijednosti.push(this.vrijednosti[j][i]);
		console.log(this.nazivi[i] + ": " + vrijednosti);
	}
}

/**
 * Pomocna funkcija koja pronalazi najveci element u nizu vrijednosti.
 * @param  {Array} niz Niz koji sadrzi nizove brojeva.
 * @return {Number} Najveci broj u nizu.
 */
function pronadi_max(niz){
	var max = -1;
	for (var i = 0; i < niz.length; i++) {
		for (var j = 0; j < niz[i].length; j++) {
			if(max < niz[i][j])
				max = niz[i][j];
		}
	}
	return max;
}

/**
 * Pomocna funkcija koja crta naslov na vrh canvasa, na sredini.
 * @param  {String} naslov Tekst koji se ispise.
 * @param  {Canvas} ctx Canvas na koji pise.
 * @param  {Number} dim_canvasa_x Sirina canvasa.
 */
function nacrtaj_naslov(naslov, ctx, dim_canvasa_x){
	ctx.font="20px Arial";
	var duljina_naslova = ctx.measureText(naslov).width/2;
	ctx.fillText(naslov, dim_canvasa_x/2 - duljina_naslova, 20);
	ctx.font="10px sans-serif";

}

/**
 * Funkcija koja crta kvadrate i nazive grupa i odreduje koja grupa je prikazana kojom bojom.
 * @param  {[Array]} grupe Niz stringova koji oznacavaju razlicite grupe podataka.
 * @param  {Canvas} ctx Canvas na koji pise.
 */
function nacrtaj_grupe(grupe, ctx){
	var pocetak_crtanja = 150;
	for (var i = 0; i < grupe.length; i++) {
		ctx.fillStyle = boje[i];
		ctx.fillRect(pocetak_crtanja, 38, 20, 20);
	 	ctx.fillText(grupe[i], pocetak_crtanja + 30, 50);
	 	pocetak_crtanja += 20 + ctx.measureText(grupe[i]).width + 40;
	}
	ctx.fillStyle = "black";
}

/**
 * Funkcija koja postavi koordinatu 0,0 u donji lijevi kut, te promijeni
 * nacin setanja po canvasu tako da gornji desni kut ima najvece koordinate.
 * @param  {Number} dim Visina canvasa.
 * @param  {Canvas} ctx Canvas koji se mijenja.
 */
function postavi_pocetnu_tocku(dim, ctx) {
	ctx.translate(0, dim);
	ctx.scale(1 , -1);
}

/**
 * Funkcija koja crta x i y osi s pocetkom u tocki (mjesto_za_pisanje, mjesto_za_pisanje).
 * @param  {Number} mjesto_za_pisanje Pocetna tocka grafa.
 * @param  {Number} sirina_grafa Tocka do koje graf ide u sirinu.
 * @param  {Number} visina_grafa Tocka do koje graf ide u visinu.
 * @param  {String} xlabel Ime x - osi. 
 * @param  {String} ylabel Ime y - osi. 
 * @param  {Canvas} ctx Canvas na koji pise.
 */
function nacrtaj_x_i_y_os(mjesto_za_pisanje, sirina_grafa, visina_grafa, xlabel, ylabel, ctx){
	ctx.beginPath();
	ctx.moveTo(mjesto_za_pisanje, mjesto_za_pisanje);
	ctx.lineTo(sirina_grafa, mjesto_za_pisanje);
	ctx.moveTo(mjesto_za_pisanje, mjesto_za_pisanje);
	ctx.lineTo(mjesto_za_pisanje, visina_grafa);

	ctx.scale(1 , -1);
	ctx.fillText(xlabel, sirina_grafa-20, -mjesto_za_pisanje + 20);
	ctx.fillText(ylabel, mjesto_za_pisanje-50, -visina_grafa - 20);
	ctx.scale(1 , -1);

	ctx.stroke();
}

/**
 * Funkcija koja odreduje koliko ce stupci biti siroki.
 * @param  {[type]} velicina_osi_za_stupce Duljina osi na kojoj ce biti stupci.
 * @param  {[type]} broj_elemenata Broj razlicitih elemenata u grafu.
 * @param  {[type]} broj_grupa Broj razlicitih grupa elemenata u grafu.
 */
function definiraj_sirinu_stupca(velicina_osi_za_stupce, broj_elemenata, broj_grupa){
	return parseInt(velicina_osi_za_stupce / ((broj_elemenata + 1) * broj_grupa), 10);
}

/**
 * Funkcija koja crta u dani canvas crta dani graf.
 * @param  {[type]} graf Objekt koji sadrzi sve informacije o grafu.
 * @param  {Canvas} ctx Canvas na koji se crta graf.
 */
function graf_horizontalni(graf, ctx) {


	var dim_canvasa_x = 800;
	var dim_canvasa_y = 600;
	var visina_grafa = 500;
	var sirina_grafa = 750;
	var mjesto_za_pisanje = 100; 
	var sirina_crtica = 10;
	var broj_crtica = 8;
	var max_vrijednost = pronadi_max(graf.vrijednosti);
	var sirina_stupca = definiraj_sirinu_stupca(650, graf.vrijednosti.length, graf.nazivi.length);


	nacrtaj_naslov(graf.title, ctx, dim_canvasa_x)
	nacrtaj_grupe(graf.dataset, ctx);

	postavi_pocetnu_tocku(dim_canvasa_y, ctx);

	nacrtaj_x_i_y_os(mjesto_za_pisanje, sirina_grafa, visina_grafa, graf.xlabel, graf.ylabel, ctx);
	
	
	var xScale = 1;
	var yScale =  (visina_grafa - mjesto_za_pisanje - 50) / max_vrijednost;
	
	var korak = parseInt(max_vrijednost / broj_crtica , 10);
	var skalirani_korak = korak * yScale;

	var duljina_brojeva = ctx.measureText(max_vrijednost).width;

	//crtanje crtica i vrijednosti na y osi.
	ctx.beginPath();
	for (var i = mjesto_za_pisanje, brojevi = 0; i <= visina_grafa; i += skalirani_korak, brojevi += korak) {
		ctx.moveTo(mjesto_za_pisanje - sirina_crtica, i)
		ctx.lineTo(mjesto_za_pisanje, i)
		ctx.scale(1, -1);
		ctx.fillText(brojevi, mjesto_za_pisanje - duljina_brojeva - 10,-i+3);
		ctx.scale(1, -1);
	}
	ctx.stroke()

	//crtanje stupaca, crtica ispod stupaca i imena
	var odmak = mjesto_za_pisanje;
	var visina_za_tekst = -50;
	ctx.beginPath();
	for (var i=0; i<graf.nazivi.length; i++) {
		for (var j=-1; j<graf.vrijednosti.length; j++) {
			if(j != -1)	{
				ctx.fillStyle = boje[j];
				ctx.fillRect(odmak, mjesto_za_pisanje, sirina_stupca, graf.vrijednosti[j][i] * yScale);
			}
			odmak += sirina_stupca;

			if(j == -1) {
				ctx.moveTo(odmak + sirina_stupca*graf.vrijednosti.length/2, mjesto_za_pisanje);
				ctx.lineTo(odmak + sirina_stupca*graf.vrijednosti.length/2, (mjesto_za_pisanje - sirina_crtica));
				ctx.scale(1, -1);
				ctx.fillStyle = "black";
				var duljina_teksta = ctx.measureText(graf.nazivi[i]).width/2;
				ctx.fillText(graf.nazivi[i], odmak + sirina_stupca*graf.vrijednosti.length/2 - duljina_teksta, visina_za_tekst + (i%2 * 20));
				ctx.scale(1, -1);
			}

		
		}
	}
	ctx.stroke();	


}

/**
 * Metoda objekta graf koja odlucuje kakav graf ce biti iscrtan
 * @param  {Int} redni_broj Redni broj grafa. Potreban da znamo gdje graf smjestiti.
 */
Graf.prototype.crtaj_graf = function(redni_broj) {
	var can = '<br><canvas height="600" width="800" id="canvas' + redni_broj + '" style="border:1px solid #d3d3d3;"></canvas>';
	
	var h2 = $("h2")
	h2.eq(redni_broj).append(can);
	
	var ctx = $( "#canvas"+redni_broj ).get(0).getContext( "2d" );
	
	graf_horizontalni(this, ctx);
}

/**
 * Pomocni objekt koji sluzi pomaze pri ucitavanju podataka.
 * Koristi ga se radi sortiranja.
 * @param {String} ime Naziv predmeta.
 * @param {Number} vrijednost Vrijednost koju ime ima.
 */
function Objekt(ime, vrijednost) {
	this.ime = ime;
	this.vrijednost = vrijednost;
}

/**
 * Funkcija koja prode po cijelom dokumentu i pronade sve odgovarajuce podatke.
 * Podatke spremi u objekt Graf koji sadrzi sve potrebene elemente za crtanje grafa.
 * @param  {Array} grafovi Niz u kojem su spremljeni svi grafovi.
 *
 */
function ucitaj_podatke(grafovi) {
   	var svi_grafovi = $(".chart");

	for(var i=0; i < svi_grafovi.length; i++) {

		var graf = new Graf();
		graf.xlabel = svi_grafovi.eq(i).data("xlabel");
		if(graf.xlabel == undefined)
			graf.xlabel = "";
		graf.ylabel = svi_grafovi.eq(i).data("ylabel");
		if(graf.ylabel == undefined)
			graf.ylabel = "";
		graf.title = svi_grafovi.eq(i).prop("title");

		svi_grafovi.eq(i).prop("style", "display:none");
		
		var elementi_grafa = svi_grafovi.eq(i).children();

		for(var j=0; j < elementi_grafa.length; j++) {

			graf.dataset.push(elementi_grafa.eq(j).data("dataset"));


			var podskup_grafa = elementi_grafa.eq(j).children();
			
			var za_crtanje = [];
			for(var k=0; k < podskup_grafa.length; k++)
				za_crtanje.push(new Objekt(podskup_grafa.eq(k).html(), podskup_grafa.eq(k).data("value")));
		
			za_crtanje.sort( function (a, b) {  
				return (a.ime < b.ime) ? - 1 : ((a.ime > b.ime) ? 1 : 0 );  
			} );

			var nazivi = [];
			var vrijednosti = [];
			for(ii in za_crtanje) {
				nazivi.push(za_crtanje[ii].ime);
				vrijednosti.push(za_crtanje[ii].vrijednost);
			}

			if(j == 0) {
				graf.nazivi = nazivi;
				graf.vrijednosti.push(vrijednosti);
			}
			else
				graf.vrijednosti.push(vrijednosti);
		}

		grafovi.push(graf);
	}
}

/**
 * Funkcija koja se pozove nakon sto se dokumet ucita.
 * Funkcija poziva pomocne funkcije koje ucitaju potrebne podatke
 * te za sve ucitane podatke pozove odgovarajuci graf.
 */
$( document ).ready( function() {

	var grafovi = [];
	ucitaj_podatke(grafovi);

	for(var i = 0; i < grafovi.length; i++)
		grafovi[i].crtaj_graf(i);
	

} );					